import express from 'express'; import r from './routes/blog.js'; const app=express(); app.use(express.json()); app.use(r); app.listen(4020,()=>console.log('content-service on 4020'));
