export async function runLLM(){ return { text: '# Outline\n- Intro' }; }
