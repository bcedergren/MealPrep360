export async function initMongo(){/* stub */}
