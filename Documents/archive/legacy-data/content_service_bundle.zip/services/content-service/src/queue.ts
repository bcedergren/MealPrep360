export const contentQueue:any={ add: async ()=>({ id:'1' }) }; export function defaultJobOpts(){ return {}; }
