Content-service bundle.
