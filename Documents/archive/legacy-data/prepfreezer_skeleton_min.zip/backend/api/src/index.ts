import http from 'http';
const server = http.createServer((_, res) => {
  res.writeHead(200, {'Content-Type': 'application/json'});
  res.end(JSON.stringify({ok:true}));
});
server.listen(process.env.PORT || 8080, () => console.log('API up'));
