#!/usr/bin/env bash
set -euo pipefail
ENV=${1:-dev}; REGION=${2:-us-east-1}
PREFIX="prepfreezer-$ENV"
aws s3api create-bucket --bucket "$PREFIX-labels" --region "$REGION" --create-bucket-configuration LocationConstraint="$REGION" || true
aws ecr create-repository --repository-name "$PREFIX-api" || true
aws ecs create-cluster --cluster-name "$PREFIX-cluster" >/dev/null || true
echo "{\"region\":\"$REGION\",\"prefix\":\"$PREFIX\"}" > infra/env.json
