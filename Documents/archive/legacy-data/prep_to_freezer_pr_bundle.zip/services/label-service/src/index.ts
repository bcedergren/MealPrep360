
import express from 'express';
import PDFDocument from 'pdfkit';
import QRCode from 'qrcode';
import { requireAuth } from './auth';

const app = express(); app.use(express.json());
app.get('/healthz', (_,res)=>res.send('ok'));

app.post('/labels/print', requireAuth, async (req,res)=>{
  const { mealUnitIds=[], format='avery_5160' } = req.body||{};
  res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition','inline; filename="labels.pdf"');
  const doc = new PDFDocument({ size: 'LETTER', margin: 36 }); doc.pipe(res);
  const cols=3, rows=10, cellW=180, cellH=72;
  for (let i=0;i<mealUnitIds.length;i++){
    if (i>0 && i%(cols*rows)===0) doc.addPage();
    const idx=i%(cols*rows), r=Math.floor(idx/cols), c=idx%cols;
    const x=36+c*cellW, y=36+r*cellH; const code=String(mealUnitIds[i]).slice(-10).toUpperCase();
    const qr = await QRCode.toDataURL(code, { margin:0, scale:4 });
    const data = Buffer.from(qr.replace(/^data:image\/png;base64,/, ''), 'base64');
    doc.image(data, x+5, y+5, { width:64, height:64 }); doc.fontSize(12).text(`Meal Code: ${code}`, x+75, y+10);
  }
  doc.end();
});

const PORT = process.env.PORT||4002; app.listen(PORT, ()=>console.log('label-service', PORT));
