
import express from 'express';
import { MongoClient } from 'mongodb';
import { idempotent } from '@mealprep360/idempotency';
import { publish } from '@mealprep360/events';
import { requireAuth } from './auth';

const app = express(); app.use(express.json()); app.use(idempotent());
let db:any, mealUnits:any;
(async()=>{
  const client = await new MongoClient(process.env.MONGODB_URI||'mongodb://localhost:27017').connect();
  db = client.db(process.env.FREEZER_DB||'mealprep360');
  mealUnits = db.collection('meal_units');
  await mealUnits.createIndex({ state:1, labelCode:1 });
})().catch(e=>{ console.error(e); process.exit(1); });

app.get('/healthz', (_,res)=>res.send('ok'));

function shortCode(b:string, i:number){ return (b||'B')+'-'+i.toString(36).toUpperCase(); }

app.post('/freezer/meal-units/batch', requireAuth, async (req,res)=>{
  const { batchId, items=[] } = req.body||{};
  const now = new Date();
  const docs = items.map((i:any, idx:number)=>({ recipeId:i.recipeId, servings:i.servings, state:'planned', container:i.container, location:i.location, labelCode: shortCode(batchId, idx), createdAt:now, updatedAt:now }));
  if(docs.length) await mealUnits.insertMany(docs);
  res.send({ mealUnits: docs.map((d:any)=>({ id:String(d._id), labelCode:d.labelCode })) });
});

app.post('/freezer/scan', requireAuth, async (req,res)=>{
  const { labelCode, action } = req.body||{};
  const mu = await mealUnits.findOne({ labelCode }); if(!mu) return res.status(404).send({error:'not found'});
  const map:any = { freeze:'frozen', thaw:'thawed', consume:'consumed', discard:'discarded' };
  const to = map[action]; if(!to) return res.status(400).send({error:'bad action'});
  await mealUnits.updateOne({ _id: mu._id }, { $set: { state: to, updatedAt: new Date() } });
  await publish({ type:'meal_state_changed', ts:new Date().toISOString(), payload:{ from:mu.state, to, labelCode } });
  const latest = await mealUnits.findOne({ _id: mu._id });
  res.send({ id:String(mu._id), state: latest.state });
});

app.get('/freezer', requireAuth, async (req,res)=>{
  const q:any = {}; if(req.query.state) q.state = req.query.state;
  const items = await mealUnits.find(q).limit(500).toArray();
  res.send({ items: items.map((x:any)=>({ id:String(x._id), recipeId:x.recipeId, state:x.state })) });
});

const PORT = process.env.PORT || 4001; app.listen(PORT, ()=>console.log('freezer-service', PORT));
