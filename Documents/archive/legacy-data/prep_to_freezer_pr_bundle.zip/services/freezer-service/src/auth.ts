
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import jwksClient from 'jwks-rsa';

const issuer = process.env.CLERK_ISSUER || "https://clerk.[your-domain].com";
const client = jwksClient({ jwksUri: `${issuer}/.well-known/jwks.json` });

function getKey(header:any, callback:any){
  client.getSigningKey(header.kid, function(err, key:any){
    const signingKey = key?.getPublicKey();
    callback(null, signingKey);
  });
}

export function requireAuth(req: Request, res: Response, next: NextFunction){
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!token) return res.status(401).send({error:"missing token"});
  jwt.verify(token, getKey, { audience: process.env.CLERK_AUDIENCE, issuer }, function(err, decoded){
    if (err) return res.status(401).send({error:"invalid token"});
    (req as any).user = decoded;
    next();
  });
}
