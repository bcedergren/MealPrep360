export type Unit='g'|'ml'|'count'; export function toCanonical(q:number,u:Unit,d?:number){ if(u==='g')return{qty:q,unit:'g'}; if(u==='ml')return{qty:d?q*d:q,unit:'g'}; return{qty:q,unit:'count'} }
