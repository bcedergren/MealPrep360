PR bundle with freezer/labels/scheduler/optimizer/pricing services, packages, k8s, and CI.
